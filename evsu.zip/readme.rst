**************************************************
This Project is Based in PHP Codeigniter Framework
**************************************************



*****************************************************************
EVSU-COE On the Job Training Monitoring and Online Grading System
*****************************************************************



########################
Objective of the Project
########################

##################
General Objective:
##################

This project will eliminate common problems caused by the traditional way of managing the grades, performance of the OJT's. To create an online grading system primarily for the Enginnering Department of the Eastern Visayas State University

Our goal has its goal to make the work of our professors easier and for the students to be more aware of their grades.

####################
Specific Objectives:
####################

■ To design a more organized way of submitting the grades of the OJT's.

■ To help the industry partners of EVSU to submit the grades of the of the OJT's in their agency in a faster and more effecient way.

■ To allow the OJT Coordinators to manage and monitor the OJT status and grades of the students more conveniently.

■ To create a module that will compute intern's grades based on inputted data.

■ To create a system that will secure and maintain the integrity of data.

■ To create a module that will keep the records of every intern in different agencies or companies.