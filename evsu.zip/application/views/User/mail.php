 <div style="width: 700px;margin: 0 auto;">
    <div style="padding-top: 10px;padding-bottom: 10px;border-bottom: 2px solid #d9534f">
        <img src="<?= base_url()?>/assets/images/EVSU_banner.png" width="700" height="60" />
    </div>
    <div style="padding: 20px">
        <div style="border: 1px solid rgb(220,230,242); padding: 10px;font-family: Calibri">
            Hello '.$user->email.',<br/>
            <br/>
                                
            You received this email as your coordinator want to rate you to other trainee in different agency.
            <br>
            <br>
            Visit the link we provided so you can rate or evaluate your co-trainee <a href="<?= base_url() ?>Login/PTPgrades?studID=2013-02261  ">Here</a>.
            <br/>
            <br/>
            Or you can copy this link and paste it on your browser url <a href="http://evsu-coe-ojt.890m.com/Login/PTPgrades?studID=2013-02261">http://evsu-coe-ojt.890m.com/Login/PTPgrades?studID=2013-02261</a>                   
            <br/>
            <br/>
            Make sure that you fill all the required field.
            <br/>
            Thanks!
            <br/>
            <br/>
                                
            Best regards,<br/>
            <br/>
            OJT Coordinator
            <br/>
            <br/>
            <div align="center">
                <h3>Share Us On</h3>
                    <ul class="list-inline">
                        <li class="social">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fevsu-coe-ojt-monitoring-and-online-grading-system.com%2F&amp;src=sdkpreparse"><img src="<?php echo base_url();?>assets/images/fb.png" alt="facebook" height="55" width="55"></a>
                        </li>
                        <li class="social">
                            <a href="https://twitter.com/share" data-show-count="false"><img src="<?php echo base_url();?>assets/images/twitter.png" alt="twitter" height="55" width="55"></a></li>
                        <li class="social">
                            <a href="https://plus.google.com/share?url={evsu-coe-ojt-monitoring-and-online-grading-system.com}" onclick="javascript:window.open(this.href,
                                          '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" >
                                <img src="<?php echo base_url();?>assets/images/googleplus.png" alt="google-plus" height="50" width="50">
                            </a>
                        </li>
                    </ul>
            </div>
        </div>
    </div>                  
</div>
                            