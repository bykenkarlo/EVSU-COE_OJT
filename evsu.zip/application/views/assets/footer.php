
<footer class="footer" id="non-printable" style="border-top: 7px #b20000 solid; border-bottom: : 7px #b20000 solid; font-size: 17px;">
	<div class="row">
		<div class="col-sm-12 text-center" id="footer_social_img" style="margin: 1em 0px 0px 0px;">
			<ul class="list-inline">
				<li style="text-align: center; margin-left: 2em;">
					<small>
						2016-<?= date("Y")?> &copy; EVSU-COE OJT Online Monitoring and Grading System. All Rights Reserved    
					</small> 
					<!-- <small class="social col-sm-12">
						By: <a style="color: #fff;" href="https://ph.linkedin.com/in/kenkarlopadal">Easter Visayas State University</a>
					</small> -->
				</li>			
				
			</ul>
			<ul class="list-inline">
				<li style="text-align: center;margin-bottom: 20px;margin-top: 20px; margin-left: : 40px;"><span>CONNECT WITH US</span></li><br/>
				<li class="social">
					<a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fevsu-coe-ojt.890m.com%2F&amp;src=sdkpreparse"><img src="<?php echo base_url();?>assets/images/fb.png" alt="facebook" height="50" width="50"></a>
				</li>
				<li class="social">
					<a class="twitter-share-button"
					  href="https://twitter.com/intent/tweet?text=On the Job Training Monitoring and Online Grading System - http://evsu-coe-ojt.890m.com/">
					<img src="<?php echo base_url();?>assets/images/twitter.png" alt="twitter" height="50" width="50"></a></li>
				<li class="social">
					<a href="https://plus.google.com/share?url=http://evsu-coe-ojt.890m.com/" onclick="javascript:window.open(this.href,
				  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" ><img src="<?php echo base_url();?>assets/images/googleplus.png" alt="google-plus" height="50" width="50"></a>
				</li>
			</ul>			
		</div>
</footer>
<script>
	function openNav() {
	    document.getElementById("mySidenav").style.width = "250px";
	    document.getElementById("main").style.marginLeft = "250px";
	}
	function closeNav() {
	    document.getElementById("mySidenav").style.width = "";
	    document.getElementById("main").style.marginLeft= "";
	}
	</script>
	</body>
</html>



